// layerVisibility.js

export function addLayerVisibilityHandlers(layers) {
  const { africa_shape, offshore_shapes, gadm_shapes, countries, all_clean_lines, generators, substations, lines, buses } = layers;

  // Toggles the visibility of the Africa shape layer
  document
      .getElementById("toggle-africa-shape")
      .addEventListener("change", function () {
          africa_shape.setVisible(this.checked);
      });

  // Repeats the same pattern for other layers, adjusting visibility based on toggle state
  document
      .getElementById("toggle-offshore-shapes")
      .addEventListener("change", function () {
          offshore_shapes.setVisible(this.checked);
      });
  document
      .getElementById("toggle-gadm-shapes")
      .addEventListener("change", function () {
          gadm_shapes.setVisible(this.checked);
      });
  document
      .getElementById("toggle-countries")
      .addEventListener("change", function () {
          countries.setVisible(this.checked);
      });
  document
      .getElementById("toggle-all-clean-lines")
      .addEventListener("change", function () {
          all_clean_lines.setVisible(this.checked);
      });
  document
      .getElementById("toggle-all-clean-generators")
      .addEventListener("change", function () {
          generators.setVisible(this.checked);
      });
  document
      .getElementById("toggle-all-clean-substations")
      .addEventListener("change", function () {
          substations.setVisible(this.checked);
      });
  document
      .getElementById("toggle-lines")
      .addEventListener("change", function () {
          lines.setVisible(this.checked);
      });
  document
      .getElementById("toggle-buses")
      .addEventListener("change", function () {
          buses.setVisible(this.checked);
      });
}