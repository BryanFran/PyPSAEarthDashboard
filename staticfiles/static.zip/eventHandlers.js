import { loadNominalGeneratorCapacityData, loadOptimalGeneratorCapacityData, loadNominalStorageCapacityData, loadOptimalStorageCapacityData, loadLineData } from './dataLoaders.js';

export function addMapEventHandlers(map, buses, lines, overlays) {
    const { labelOverlay, lineLabelOverlay } = overlays;

    // Handles click events on the map, showing labels for buses or lines if clicked
    map.on("singleclick", function (evt) {
        const viewResolution = map.getView().getResolution();
        let clickedSomething = false;

        // Process clicks on buses, displaying specific information and labels
        const busUrl = buses
            .getSource()
            .getFeatureInfoUrl(evt.coordinate, viewResolution, "EPSG:3857", {
                INFO_FORMAT: "application/json",
            });

        if (busUrl) {
            fetch(busUrl)
                .then((response) => response.json())
                .then((data) => {
                    if (data.features.length > 0) {
                        clickedSomething = true;
                        handleBusClick(data.features[0], evt.coordinate, labelOverlay);
                    }
                });
        }

        // Process clicks on lines, similarly displaying labels and information
        const lineUrl = lines
            .getSource()
            .getFeatureInfoUrl(evt.coordinate, viewResolution, "EPSG:3857", {
                INFO_FORMAT: "application/json",
            });

        if (lineUrl) {
            fetch(lineUrl)
                .then((response) => response.json())
                .then((data) => {
                    if (data.features.length > 0) {
                        clickedSomething = true;
                        handleLineClick(data.features[0], evt.coordinate, lineLabelOverlay);
                    }
                });
        }

        // If no specific feature was clicked, reset any displayed information or labels
        if (!clickedSomething) {
            resetCharts();
            document.getElementById("map-label").style.display = "none";
            document.getElementById("line-map-label").style.display = "none";
        }
    });
}

// Functions for handling clicks on buses or lines, updating labels, and loading additional data
export function handleBusClick(busFeature, coordinate, labelOverlay) {
    const busId = busFeature.properties.Bus;
    document.getElementById("line-map-label").innerHTML = ""; // Cleans Line Label
    updateLabelForBus(busId, coordinate, labelOverlay); // Updates label with bus Id
    // Load specific data for the clicked bus
    loadNominalGeneratorCapacityData(busId);
    loadOptimalGeneratorCapacityData(busId);
    loadNominalStorageCapacityData(busId);
    loadOptimalStorageCapacityData(busId);
}

export function handleLineClick(lineFeature, coordinate, lineLabelOverlay) {
    const lineId = lineFeature.properties.Line;
    document.getElementById("map-label").innerHTML = "";
    updateLabelForLine(lineId, coordinate, lineLabelOverlay); // Update label with line ID
    // Load specific data for the clicked line
    loadLineData(lineId);
}

// Updates the label's text and visibility based on the selected bus or line
export function updateLabelForBus(busId, coordinate, labelOverlay) {
    const labelElement = document.getElementById("map-label");
    labelElement.innerHTML = `Bus: ${busId}`;
    if (busId) {
        labelElement.style.display = "block";
    } else {
        labelElement.style.display = "none";
    }
    labelOverlay.setPosition(coordinate);
}

// Label for lines
export function updateLabelForLine(lineId, coordinate, lineLabelOverlay) {
    const lineLabelElement = document.getElementById("line-map-label");
    lineLabelElement.innerHTML = `Line: ${lineId}`;
    if (lineId) {
        lineLabelElement.style.display = "block";
    } else {
        lineLabelElement.style.display = "none";
    }
    lineLabelOverlay.setPosition(coordinate);
}

// Resets the display of any specific data or labels, reverting to a general state
export function resetCharts() {
    // Placeholder functions for resetting displayed data
    loadNominalGeneratorCapacityData();
    loadOptimalGeneratorCapacityData();
    loadNominalStorageCapacityData();
    loadOptimalStorageCapacityData();
    loadLineData();
    // Hide any labels that might be visible
    document.getElementById("map-label").style.display = "none";
    document.getElementById("line-map-label").style.display = "none";
}
