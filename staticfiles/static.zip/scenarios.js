var mapInstances = {};

export function initializeMap(mapId, carrier, variable) {
  const mapElement = document.getElementById(mapId);
  if (!mapElement) return;

  const longitude = -72.33728;
  const latitude = 4.26508;

  if (mapInstances[mapId]) {
    mapInstances[mapId].setTarget(null);
  }

  let wfsUrl = "";
  if (carrier === "solar") {
    wfsUrl =
      "http://localhost:8080/geoserver/wfs?service=WFS&version=1.0.0&request=GetFeature&typeName=PyPSAEarthDashboard:solar_CO&outputFormat=application/json";
  } else if (carrier === "onwind") {
    wfsUrl =
      "http://localhost:8080/geoserver/wfs?service=WFS&version=1.0.0&request=GetFeature&typeName=PyPSAEarthDashboard:onwind_CO&outputFormat=application/json";
  }

  console.log("WFS URL:", wfsUrl);

  const vectorSource = new ol.source.Vector({
    format: new ol.format.GeoJSON(),
    url: wfsUrl,
    strategy: ol.loadingstrategy.all,
  });

  const vectorLayer = new ol.layer.Vector({
    source: vectorSource,
    style: (feature) => getChoroplethStyle(feature, variable, carrier, mapId),
  });

  const map = new ol.Map({
    target: mapId,
    layers: [
      new ol.layer.Tile({
        source: new ol.source.OSM(),
      }),
      vectorLayer,
    ],
    view: new ol.View({
      center: ol.proj.fromLonLat([longitude, latitude]),
      zoom: 4.7,
    }),
  });

  mapInstances[mapId] = map;

  fetch(wfsUrl)
    .then((response) => response.json())
    .then((data) => {
      const features = new ol.format.GeoJSON().readFeatures(data);
      console.log("WFS Data:", features);
      features.forEach((feature) => {
        console.log("Feature added:", feature);
        vectorSource.addFeature(feature);
      });
      createLegend(mapId, variable, carrier, features);
    })
    .catch((error) => console.error("Error:", error));

  const tooltip = document.createElement("div");
  tooltip.className = "tooltip";
  tooltip.style.position = "absolute";
  tooltip.style.background = "rgba(255, 255, 255, 0.8)";
  tooltip.style.border = "1px solid #ccc";
  tooltip.style.padding = "5px";
  tooltip.style.pointerEvents = "none";
  tooltip.style.display = "none";
  document.body.appendChild(tooltip);

  map.on("click", function (evt) {
    console.log("Click event detected"); // Log for debugging
    const pixel = map.getEventPixel(evt.originalEvent);
    const feature = map.forEachFeatureAtPixel(pixel, function (feature) {
      return feature;
    });

    if (feature) {
      const geographicName = feature.get("gepgraphic_name");
      const variableValue = feature.get(variable);
      tooltip.innerHTML = `<b>${geographicName}</b><br>${variable}: ${variableValue}`;
      tooltip.style.left = `${evt.pixel[0]}px`;
      tooltip.style.top = `${evt.pixel[1]}px`;
      tooltip.style.display = "block";
      console.log("Tooltip shown:", tooltip.innerHTML); // Logging for debugging
      console.log("Tooltip position:", tooltip.style.left, tooltip.style.top); // Log position
    } else {
      tooltip.style.display = "none";
      console.log("No feature found"); // Logging for debugging
    }
  });
}

function createLegend(mapId, variable, carrier, features) {
  const legendElement = document.getElementById(`map-legend-${mapId}`);
  if (!legendElement) {
    console.error(`Legend element not found for mapId: ${mapId}`);
    return;
  }

  const values = features
    .map((f) => parseFloat(f.get(variable)))
    .filter((v) => !isNaN(v) && v !== null && isFinite(v))
    .sort((a, b) => a - b);

  if (values.length === 0) {
    legendElement.innerHTML = "<div><b>No data available</b></div>";
    return;
  }

  const minValue = values[0];
  const maxValue = values[values.length - 1];

  let colors =
    carrier === "solar"
      ? [
          "rgba(255, 255, 255, 0.1)",
          "rgba(254, 217, 118, 0.6)",
          "rgba(254, 178, 76, 0.6)",
          "rgba(253, 141, 60, 0.6)",
          "rgba(252, 78, 42, 0.6)",
          "rgba(227, 26, 28, 0.6)",
          "rgba(189, 0, 38, 0.6)",
        ]
      : [
          "rgba(255, 255, 255, 0.1)",
          "rgba(254, 224, 144, 0.6)",
          "rgba(224, 243, 248, 0.6)",
          "rgba(171, 217, 233, 0.6)",
          "rgba(116, 173, 209, 0.6)",
          "rgba(69, 117, 180, 0.6)",
          "rgba(49, 54, 149, 0.6)",
        ];

  const step = (maxValue - minValue) / (colors.length - 1);
  const breaks = colors.map((color, index) => minValue + index * step);

  // Eliminate duplicate breaks
  const uniqueBreaks = [...new Set(breaks)];

  console.log("Creating legend with unique values:", uniqueBreaks);

  let legendHTML = "<div><b>Legend</b></div>";
  uniqueBreaks.forEach((breakPoint, index) => {
    legendHTML += `<div>
        <span style="background-color:${
          colors[index]
        };width:15px;height:5px;display:inline-block;border:1px solid #000;"></span> ${breakPoint.toFixed(
      3
    )}
      </div>`;
  });

  legendHTML += `<div>
      <span style="background-color:rgba(200, 200, 200, 0.5);width:15px;height:5px;display:inline-block;border:1px solid #000;"></span> No values
    </div>`;

  console.log("Generated legend:", legendHTML);

  legendElement.innerHTML = legendHTML;
}

function getChoroplethStyle(feature, variable, carrier, mapId) {
  let value = parseFloat(feature.get(variable));
  if (isNaN(value) || !isFinite(value)) {
    console.warn(`No value for variable ${variable} in feature`, feature);
    return new ol.style.Style({
      fill: new ol.style.Fill({
        color: "rgba(200, 200, 200, 0.5)", // Default gray color for no values
      }),
      stroke: new ol.style.Stroke({
        color: "#000000",
        width: 1,
      }),
    });
  }

  let colors =
    carrier === "solar"
      ? [
          "rgba(255, 255, 255, 0.1)",
          "rgba(254, 217, 118, 0.6)",
          "rgba(254, 178, 76, 0.6)",
          "rgba(253, 141, 60, 0.6)",
          "rgba(252, 78, 42, 0.6)",
          "rgba(227, 26, 28, 0.6)",
          "rgba(189, 0, 38, 0.6)",
        ]
      : [
          "rgba(255, 255, 255, 0.1)",
          "rgba(254, 224, 144, 0.6)",
          "rgba(224, 243, 248, 0.6)",
          "rgba(171, 217, 233, 0.6)",
          "rgba(116, 173, 209, 0.6)",
          "rgba(69, 117, 180, 0.6)",
          "rgba(49, 54, 149, 0.6)",
        ];

  const allFeatures = mapInstances[mapId]
    .getLayers()
    .item(1)
    .getSource()
    .getFeatures();
  const allValues = allFeatures
    .map((f) => {
      let v = parseFloat(f.get(variable));
      return !isNaN(v) && isFinite(v) ? v : null;
    })
    .filter((v) => v !== null);

  if (allValues.length === 0) {
    console.warn(`No valid values for variable ${variable}`);
    return new ol.style.Style({
      fill: new ol.style.Fill({
        color: "rgba(200, 200, 200, 0.5)", // Default gray color for no values
      }),
      stroke: new ol.style.Stroke({
        color: "#000000",
        width: 1,
      }),
    });
  }

  const minValue = Math.min(...allValues);
  const maxValue = Math.max(...allValues);
  const step = (maxValue - minValue) / (colors.length - 1);

  let breaks = colors.map((color, index) => minValue + index * step);
  breaks = [...new Set(breaks)];

  console.log("Breaks for color scale:", breaks);

  let color = colors[0];
  for (let i = 0; i < breaks.length - 1; i++) {
    if (value >= breaks[i] && value < breaks[i + 1]) {
      color = colors[i];
      break;
    }
  }

  if (value === 0) {
    color = colors[0];
  } else if (value >= breaks[breaks.length - 1]) {
    color = colors[colors.length - 1];
  }

  return new ol.style.Style({
    fill: new ol.style.Fill({
      color: color,
    }),
    stroke: new ol.style.Stroke({
      color: "#000000",
      width: 1,
    }),
  });
}

export function createScenarioControls() {
  const maps = [
    { mapId: "map1", carrier: "solar", variable: "cf" },
    { mapId: "map2", carrier: "onwind", variable: "cf" },
  ];

  maps.forEach(({ mapId, carrier, variable }) => {
    const mapElement = document.getElementById(mapId);
    const carrierSelectorId = `carrierSelector-${mapId}`;
    const variableSelectorId = `variableSelector-${mapId}`;
    const legendId = `map-legend-${mapId}`;
    const selectHTML = `
            <div class="map-select-container">
                <select id="${carrierSelectorId}" class="map-carrier-selector">
                    <option value="solar">Solar</option>
                    <option value="onwind">Onwind</option>
                </select>
                <select id="${variableSelectorId}" class="map-variable-selector">
                    <option value="cf">CF</option>
                    <option value="crt">CRT</option>
                    <option value="usdpt">USDPT</option>
                </select>
                <div id="${legendId}" class="map-legend"></div>
            </div>`;
    mapElement.innerHTML += selectHTML;

    document
      .getElementById(carrierSelectorId)
      .addEventListener("change", function () {
        const carrier = this.value;
        const variable = document.getElementById(variableSelectorId).value;
        initializeMap(mapId, carrier, variable);
      });

    document
      .getElementById(variableSelectorId)
      .addEventListener("change", function () {
        const variable = this.value;
        const carrier = document.getElementById(carrierSelectorId).value;
        initializeMap(mapId, carrier, variable);
      });

    document.getElementById(carrierSelectorId).value = carrier;
    document.getElementById(variableSelectorId).value = variable;
    initializeMap(mapId, carrier, variable);
  });
}
