// uiControls.js
import { initializeMap } from './scenarios.js';

export let isMainMapVisible = true;

export function toggleScenarios() {
    const originalMapContainer = document.getElementById('js-map');
    const dashboardContainer = document.querySelector('.dashboard-container');

    if (dashboardContainer.style.display === 'none' || !dashboardContainer.style.display) {
        dashboardContainer.style.display = 'grid';
        originalMapContainer.style.display = 'none';
        isMainMapVisible = false;

        // Obtener valores seleccionados del primer mapa
        const carrier1 = document.getElementById('carrierSelector1').value;
        const variable1 = document.getElementById('variableSelector1').value;

        // Obtener valores seleccionados del segundo mapa
        const carrier2 = document.getElementById('carrierSelector2').value;
        const variable2 = document.getElementById('variableSelector2').value;

        // Inicializar mapas con los valores seleccionados
        initializeMap('map1', `${carrier1}-${variable1}`);
        initializeMap('map2', `${carrier2}-${variable2}`);
    } else {
        dashboardContainer.style.display = 'none';
        originalMapContainer.style.display = 'block';
        isMainMapVisible = true;
    }
}


export function toggleSidebar(side, map) {
    // Verifica si el mapa principal está visible, si no, cambia a la vista del mapa principal
    if (!isMainMapVisible) {
        toggleScenarios(); // Cambia a la vista del mapa principal
        return; // Detiene la ejecución para evitar conflictos
    }

    const flexContainer = document.querySelector(".flex-grow-1");
    const leftBtn = document.getElementById("btn-toggle-left-sidebar");
    const rightBtn = document.getElementById("btn-toggle-right-sidebar");

    if (side === "left") {
        document.body.classList.toggle("show-left-sidebar");
        flexContainer.classList.toggle("map-shift-right");
    } else if (side === "right") {
        document.body.classList.toggle("show-right-sidebar");
        flexContainer.classList.toggle("map-shift-left");
        leftBtn.classList.toggle("move-right", document.body.classList.contains("show-right-sidebar"));
        rightBtn.classList.toggle("move-left", document.body.classList.contains("show-right-sidebar"));
    }

    // Asegura que el tamaño del mapa se actualice después de manipular las barras laterales
    setTimeout(() => {
        map.updateSize();
    }, 350); // Ajusta este tiempo según la duración de la transición de la sidebar
}

export function initializeUIControls(map) {
    document.getElementById("btn-toggle-left-sidebar").addEventListener('click', function () {
        toggleSidebar("left", map);
    });

    document.getElementById("btn-toggle-right-sidebar").addEventListener('click', function () {
        toggleSidebar("right", map);
    });

    document.getElementById('btn-toggle-scenarios').addEventListener('click', toggleScenarios);
}

// Modificación para agregar eventos pasivos
export function addPassiveEventListeners() {
    // Añade listeners de scroll
    document.addEventListener('scroll', function(event) {
        // Código de manejo de evento (si es necesario)
    }, { passive: true });

    // Añade listeners para eventos 'wheel' en todos los elementos canvas
    const chartElements = document.querySelectorAll('canvas');
    chartElements.forEach((element) => {
        element.addEventListener('wheel', function(event) {
            // Código de manejo de evento (si es necesario)
        }, { passive: true });
    });

    // Otros listeners de eventos de desplazamiento que podrían beneficiarse de ser pasivos
    const mapContainer = document.getElementById('js-map');
    mapContainer.addEventListener('touchstart', function(event) {
        // Código de manejo de evento (si es necesario)
    }, { passive: true });

    mapContainer.addEventListener('touchmove', function(event) {
        // Código de manejo de evento (si es necesario)
    }, { passive: true });
}