// layers.js

export function addGeoServerLayers(map) {
    const africa_shape = new ol.layer.Image({
        source: new ol.source.ImageWMS({
            url: "http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard%3Aafrica_shape&bbox=2.648432493209839%2C1.921666622161865%2C14.693286895751953%2C13.912005424499512&width=768&height=764&srs=EPSG%3A4326&styles=&format=application%2Fopenlayers3",
            params: { LAYERS: "PyPSAEarthDashboard:africa_shape", TILED: true },
            serverType: "geoserver",
        }),
    });
    map.addLayer(africa_shape);

    const offshore_shapes = new ol.layer.Image({
        source: new ol.source.ImageWMS({
            url: "http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard%3Aoffshore_shapes&bbox=2.684863567352295%2C1.921666622161865%2C8.541397094726562%2C6.429849147796631&width=768&height=591&srs=EPSG%3A4326&styles=&format=application%2Fopenlayers3",
            params: { LAYERS: "PyPSAEarthDashboard:offshore_shapes", TILED: true },
            serverType: "geoserver",
        }),
    });
    map.addLayer(offshore_shapes);

    const gadm_shapes = new ol.layer.Image({
        source: new ol.source.ImageWMS({
            url: "http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard%3Agadm_shapes&bbox=2.668430805206299%2C4.287360668182373%2C14.675124168395996%2C13.892009735107422&width=768&height=614&srs=EPSG%3A4326&styles=&format=application%2Fopenlayers3",
            params: { LAYERS: "PyPSAEarthDashboard:gadm_shapes", TILED: true },
            serverType: "geoserver",
        }),
    });

    const gadmShapesExtent = [
        2.668430805206299, 4.287360668182373, 14.675124168395996,
        13.892009735107422,
    ];
    const transformedExtent = ol.proj.transformExtent(
        gadmShapesExtent,
        "EPSG:4326",
        map.getView().getProjection()
    );
    map.addLayer(gadm_shapes);
    map.once("postrender", function () {
        map.getView().fit(transformedExtent, {
            size: map.getSize(),
            padding: [100, 100, 100, 100],
            duration: 1000,
        });
    });

    const countries = new ol.layer.Image({
        source: new ol.source.ImageWMS({
            url: "http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard%3Acountry_shapes&bbox=2.668430805206299%2C4.287360668182373%2C14.673296928405762%2C13.892009735107422&width=768&height=614&srs=EPSG%3A4326&styles=&format=application%2Fopenlayers3",
            params: { LAYERS: "PyPSAEarthDashboard:country_shapes", TILED: true },
            serverType: "geoserver",
        }),
    });
    map.addLayer(countries);

    const all_clean_lines = new ol.layer.Image({
        source: new ol.source.ImageWMS({
            url: "http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard%3Aall_clean_lines&bbox=3.148502826690674%2C4.559695243835449%2C13.139745712280273%2C13.028300285339355&width=768&height=650&srs=EPSG%3A4326&styles=&format=application%2Fopenlayers3",
            params: { LAYERS: "PyPSAEarthDashboard:all_clean_lines", TILED: true },
            serverType: "geoserver",
        }),
    });
    map.addLayer(all_clean_lines);

    const substations = new ol.layer.Image({
        source: new ol.source.ImageWMS({
            url: "http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard%3Aall_clean_substations&bbox=3.207669734954834%2C4.563215255737305%2C13.139745712280273%2C13.028435707092285&width=768&height=654&srs=EPSG%3A4326&styles=&format=application%2Fopenlayers3",
            params: {
                LAYERS: "PyPSAEarthDashboard:all_clean_substations",
                TILED: true,
            },
            serverType: "geoserver",
        }),
    });
    map.addLayer(substations);

    const generators = new ol.layer.Image({
        source: new ol.source.ImageWMS({
            url: "http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard%3AAll_clean_generators&bbox=3.614437580108643%2C4.815903663635254%2C8.273301124572754%2C12.845580101013184&width=445&height=768&srs=EPSG%3A4326&styles=&format=application%2Fopenlayers3",
            params: {
                LAYERS: "PyPSAEarthDashboard:All_clean_generators",
                TILED: true,
            },
            serverType: "geoserver",
        }),
    });
    map.addLayer(generators);

    const lines = new ol.layer.Image({
        source: new ol.source.ImageWMS({
            url: "http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard%3Anetwork_lines_view&bbox=4.034136363636363%2C6.485180952380953%2C12.06048%2C10.78015652173913&width=768&height=410&srs=EPSG%3A4326&styles=&format=application%2Fopenlayers3",
            params: { LAYERS: "PyPSAEarthDashboard:network_lines_view", TILED: true },
            serverType: "geoserver",
        }),
    });
    map.addLayer(lines);

    const buses = new ol.layer.Image({
        source: new ol.source.ImageWMS({
            url: "http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard%3ABuses_geojson_data&bbox=2.591399908065796%2C6.485180854797363%2C12.060480117797852%2C10.780157089233398&width=768&height=348&srs=EPSG%3A4326&styles=&format=application%2Fopenlayers3",
            params: { LAYERS: "PyPSAEarthDashboard:Buses_geojson_data", TILED: true },
            serverType: "geoserver",
        }),
    });
    map.addLayer(buses);

    return {
        africa_shape,
        offshore_shapes,
        gadm_shapes,
        countries,
        all_clean_lines,
        generators,
        substations,
        lines,
        buses
    };
}
