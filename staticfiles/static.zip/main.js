import { init } from './init.js';
import { addGeoServerLayers } from './layers.js';
import { addDownloadEventListeners } from './downloads.js';
import { addMapEventHandlers } from './eventHandlers.js';
import { addMapRotationInteraction } from './mapRotation.js';
import { initializeSearch } from './search.js';
import { addLayerVisibilityHandlers } from './layerVisibility.js';
import { initializeUrlHandling } from './urlHandling.js';
import { initializeUIControls } from './uiControls.js';
import { initializeDataLoading } from './dataInitialization.js';
import { createScenarioControls } from './scenarios.js';
import { addPassiveEventListeners } from './uiControls.js';
import { loadNominalGeneratorCapacityData, loadOptimalGeneratorCapacityData, loadNominalStorageCapacityData, loadOptimalStorageCapacityData, loadLineData } from './dataLoaders.js';

window.onload = async () => {
    const map = await init();
    const overlays = {
        labelOverlay: new ol.Overlay({
            element: document.getElementById('map-label'),
            positioning: 'bottom-center'
        }),
        lineLabelOverlay: new ol.Overlay({
            element: document.getElementById('line-map-label'),
            positioning: 'bottom-center'
        })
    };
    map.addOverlay(overlays.labelOverlay);
    map.addOverlay(overlays.lineLabelOverlay);
    
    const layers = addGeoServerLayers(map);
    addDownloadEventListeners();
    addMapEventHandlers(map, layers.buses, layers.lines, overlays);
    addMapRotationInteraction(map);
    initializeSearch(map);
    addLayerVisibilityHandlers(layers);
    initializeUrlHandling(map);
    initializeUIControls(map);
    initializeDataLoading();
    createScenarioControls();

    // Cargar datos iniciales para los gráficos
    loadNominalGeneratorCapacityData();
    loadOptimalGeneratorCapacityData();
    loadNominalStorageCapacityData();
    loadOptimalStorageCapacityData();
    loadLineData();
};

document.addEventListener('DOMContentLoaded', (event) => {
    addPassiveEventListeners();
});
