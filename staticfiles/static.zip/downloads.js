// downloads.js

export function createWFSDownloadUrl(layerName) {
  const geoserverUrl = "http://localhost:8080/geoserver/"; // URL of our GeoServer
  const workspace = "PyPSAEarthDashboard"; // Workspace in GeoServer
  const wfsVersion = "2.0.0"; // WFS version
  const requestType = "GetFeature"; // Request type
  const outputFormat = "application/json"; // Output format

  // Constructs and returns the full URL for the WFS request
  return `${geoserverUrl}ows?service=WFS&version=${wfsVersion}&request=${requestType}&typeName=${workspace}:${layerName}&outputFormat=${outputFormat}`;
}

export function downloadLayerData(layerName) {
  const url = createWFSDownloadUrl(layerName); // Generates the URL for the WFS request

  fetch(url)
      .then((response) => response.blob()) // Retrieves the data as a Blob
      .then((blob) => {
          // Creates a link for downloading the Blob
          const downloadUrl = window.URL.createObjectURL(blob);
          const downloadLink = document.createElement("a");
          downloadLink.href = downloadUrl;
          downloadLink.download = layerName + ".geojson"; // Sets the file name for the download
          document.body.appendChild(downloadLink);
          downloadLink.click();

          // Cleans up by removing the download link and revoking the created URL
          document.body.removeChild(downloadLink);
          window.URL.revokeObjectURL(downloadUrl);
      })
      .catch((error) => {
          console.error("Error downloading the file:", error);
      });
}

export function addDownloadEventListeners() {
  document.getElementById("download-africa-shape").addEventListener("click", () => downloadLayerData("africa_shape"));
  document.getElementById("download-offshore-shapes").addEventListener("click", () => downloadLayerData("offshore_shapes"));
  document.getElementById("download-gadm-shapes").addEventListener("click", () => downloadLayerData("gadm_shapes"));
  document.getElementById("download-countries").addEventListener("click", () => downloadLayerData("country_shapes"));
  document.getElementById("download-all-clean-lines").addEventListener("click", () => downloadLayerData("all_clean_lines"));
  document.getElementById("download-lines").addEventListener("click", () => downloadLayerData("network_lines_view"));
  document.getElementById("download-all-clean-generators").addEventListener("click", () => downloadLayerData("All_clean_generators"));
  document.getElementById("download-all-clean-substations").addEventListener("click", () => downloadLayerData("all_clean_substations"));
  document.getElementById("download-buses").addEventListener("click", () => downloadLayerData("Buses_geojson_data"));
}