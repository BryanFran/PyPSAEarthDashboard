// dataInitialization.js
import {
  loadNominalGeneratorCapacityData,
  loadOptimalGeneratorCapacityData,
  loadNominalStorageCapacityData,
  loadOptimalStorageCapacityData,
  loadLineData,
} from './dataLoaders.js';

export function initializeDataLoading() {
  document.addEventListener("DOMContentLoaded", function () {
      loadNominalGeneratorCapacityData();
      loadOptimalGeneratorCapacityData();
      loadNominalStorageCapacityData();
      loadOptimalStorageCapacityData();
      loadLineData();
  });
}