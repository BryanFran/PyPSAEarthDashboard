// mapRotation.js
export function addMapRotationInteraction(map) {
  // Enables rotation interaction by dragging with the Alt key pressed
  const dragRotateInteraction = new ol.interaction.DragRotate({
    condition: ol.events.condition.altKeyOnly,
  });
  map.addInteraction(dragRotateInteraction);
}
