# SPDX-FileCopyrightText: 2024 Bryan Ramirez
#
# SPDX-License-Identifier: AGPL-3.0-or-later
#

from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import (
    NominalGeneratorCapacity, NominalGeneratorCapacityCo,
    OptimalGeneratorCapacity, OptimalGeneratorCapacityCo,
    NominalStorageCapacity, NominalStorageCapacityCo,
    OptimalStorageCapacity, OptimalStorageCapacityCo,
    Lines, LinesCo
)

def index(request):
    return render(request, 'index.html')

@csrf_exempt
def nominal_generator_capacity_json(request, country):
    if country.lower() == 'nigeria':
        data = list(NominalGeneratorCapacity.objects.all().values())
    elif country.lower() == 'colombia':
        data = list(NominalGeneratorCapacityCo.objects.all().values())
    else:
        return JsonResponse({"error": "Country not supported"}, status=400)
    
    for item in data:
        item['geom'] = item['geom'].coords  # Convert Point to tuple

    return JsonResponse(data, safe=False)

@csrf_exempt
def optimal_generator_capacity_json(request, country):
    if country.lower() == 'nigeria':
        data = list(OptimalGeneratorCapacity.objects.all().values())
    elif country.lower() == 'colombia':
        data = list(OptimalGeneratorCapacityCo.objects.all().values())
    else:
        return JsonResponse({"error": "Country not supported"}, status=400)
    
    for item in data:
        item['geom'] = item['geom'].coords  # Convert Point to tuple

    return JsonResponse(data, safe=False)

@csrf_exempt
def nominal_storage_capacity_json(request, country):
    if country.lower() == 'nigeria':
        data = list(NominalStorageCapacity.objects.all().values())
    elif country.lower() == 'colombia':
        data = list(NominalStorageCapacityCo.objects.all().values())
    else:
        return JsonResponse({"error": "Country not supported"}, status=400)
    
    for item in data:
        item['geom'] = item['geom'].coords  # Convert Point to tuple

    return JsonResponse(data, safe=False)

@csrf_exempt
def optimal_storage_capacity_json(request, country):
    if country.lower() == 'nigeria':
        data = list(OptimalStorageCapacity.objects.all().values())
    elif country.lower() == 'colombia':
        data = list(OptimalStorageCapacityCo.objects.all().values())
    else:
        return JsonResponse({"error": "Country not supported"}, status=400)
    
    for item in data:
        item['geom'] = item['geom'].coords  # Convert Point to tuple

    return JsonResponse(data, safe=False)

@csrf_exempt
def line_data_json(request, country):
    if country.lower() == 'nigeria':
        data = list(Lines.objects.all().values())
    elif country.lower() == 'colombia':
        data = list(LinesCo.objects.all().values())
    else:
        return JsonResponse({"error": "Country not supported"}, status=400)
    
    for item in data:
        item['line_geom'] = item['line_geom'].coords  # Convert Geometry to tuple or appropriate format

    return JsonResponse(data, safe=False)
