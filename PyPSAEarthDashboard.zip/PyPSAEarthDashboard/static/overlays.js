// overlays.js

export function createOverlays(map) {
  // Creates a div element for the Bus or Line Label and then it is added to the DOM
  const labelElement = document.createElement("div");
  labelElement.id = "map-label";
  labelElement.style.position = "absolute";
  labelElement.style.backgroundColor = "rgba(255, 255, 255, 0.7)";
  labelElement.style.padding = "2px";
  labelElement.style.borderRadius = "5px";
  labelElement.style.fontSize = "0.7rem";
  labelElement.style.whiteSpace = "nowrap";
  labelElement.style.fontWeight = "bold";
  labelElement.style.display = "none"; // Initially hidden

  // Add the label as a child of the map div
  document.getElementById("js-map").appendChild(labelElement);

  const lineLabelElement = document.createElement("div");
  lineLabelElement.id = "line-map-label";
  lineLabelElement.style.position = "absolute";
  lineLabelElement.style.backgroundColor = "rgba(255, 255, 255, 0.7)";
  lineLabelElement.style.padding = "2px";
  lineLabelElement.style.borderRadius = "5px";
  lineLabelElement.style.fontSize = "0.7rem";
  lineLabelElement.style.whiteSpace = "nowrap";
  lineLabelElement.style.fontWeight = "bold";
  lineLabelElement.style.display = "none";

  document.getElementById("js-map").appendChild(lineLabelElement);

  // Label for Buses
  const labelOverlay = new ol.Overlay({
      element: labelElement,
      positioning: "bottom-center",
      stopEvent: false,
      offset: [0, -10], // Here it can be modified as desired
  });
  map.addOverlay(labelOverlay);

  // Label for Lines
  const lineLabelOverlay = new ol.Overlay({
      element: lineLabelElement,
      positioning: "bottom-center",
      stopEvent: false,
      offset: [0, -10], // Here it can be modified as desired
  });
  map.addOverlay(lineLabelOverlay);

  return { labelOverlay, lineLabelOverlay };
}
