import { init } from './init.js';
import { loadLayers, clearLayers } from './layers.js';
import { addDownloadEventListeners } from './downloads.js';
import { addMapEventHandlers } from './eventHandlers.js';
import { addMapRotationInteraction } from './mapRotation.js';
import { initializeSearch } from './search.js';
import { addLayerVisibilityHandlers, updateLayerVisibility } from './layerVisibility.js';
import { initializeUrlHandling } from './urlHandling.js';
import { initializeUIControls } from './uiControls.js';
import { initializeDataLoading } from './dataInitialization.js';
import { createScenarioControls } from './scenarios.js';
import { addPassiveEventListeners } from './uiControls.js';
import { loadNominalGeneratorCapacityData, loadOptimalGeneratorCapacityData, loadNominalStorageCapacityData, loadOptimalStorageCapacityData, loadLineData } from './dataLoaders.js';
import { createOverlays } from './overlays.js';

window.onload = async () => {
    const map = await init();
    window.map = map; // Make the map globally accessible
    const overlays = createOverlays(map);
    window.overlays = overlays; // Make overlays globally accessible
    const defaultCountry = 'Nigeria';

    let layers = loadLayers(map, defaultCountry);

    addDownloadEventListeners();
    addMapEventHandlers(map, layers.buses, layers.lines, overlays, defaultCountry);
    addMapRotationInteraction(map);
    initializeSearch(map, (selectedCountry) => {
        clearLayers(map);
        layers = loadLayers(map, selectedCountry);
        addMapEventHandlers(map, layers.buses, layers.lines, overlays, selectedCountry);
        addLayerVisibilityHandlers(layers); // Add visibility handlers for the new layers
        updateLayerVisibility(layers); // Update the visibility based on the new layers
    });
    addLayerVisibilityHandlers(layers);
    initializeUrlHandling(map);
    initializeUIControls(map);
    initializeDataLoading();
    createScenarioControls();

    // Load initial data for charts
    loadNominalGeneratorCapacityData(defaultCountry);
    loadOptimalGeneratorCapacityData(defaultCountry);
    loadNominalStorageCapacityData(defaultCountry);
    loadOptimalStorageCapacityData(defaultCountry);
    loadLineData(defaultCountry);
};

document.addEventListener('DOMContentLoaded', (event) => {
    addPassiveEventListeners();
});
