import { loadNominalGeneratorCapacityData, loadOptimalGeneratorCapacityData, loadNominalStorageCapacityData, loadOptimalStorageCapacityData, loadLineData } from './dataLoaders.js';

export function addMapEventHandlers(map, busesLayerName, linesLayerName, overlays, country) {
    const { labelOverlay, lineLabelOverlay } = overlays;

    map.on("singleclick", function (evt) {
        const viewResolution = map.getView().getResolution();
        let clickedSomething = false;

        // Check for buses
        if (busesLayerName) {
            const busLayer = map.getLayers().getArray().find(layer => {
                const source = layer.getSource();
                return source && source.getParams && source.getParams().LAYERS === busesLayerName;
            });

            if (busLayer) {
                const busUrl = busLayer
                    .getSource()
                    .getFeatureInfoUrl(evt.coordinate, viewResolution, "EPSG:3857", {
                        INFO_FORMAT: "application/json",
                    });

                if (busUrl) {
                    fetch(busUrl)
                        .then(response => {
                            if (!response.ok) {
                                throw new Error(`HTTP error! Status: ${response.status}`);
                            }
                            return response.json();
                        })
                        .then(data => {
                            if (data.features && data.features.length > 0) {
                                clickedSomething = true;
                                handleBusClick(data.features[0], evt.coordinate, labelOverlay, country);
                            }
                        })
                        .catch(error => console.error(`Failed to load bus data from ${busUrl}:`, error));
                }
            }
        }

        // Check for lines
        if (linesLayerName) {
            const lineLayer = map.getLayers().getArray().find(layer => {
                const source = layer.getSource();
                return source && source.getParams && source.getParams().LAYERS === linesLayerName;
            });

            if (lineLayer) {
                const lineUrl = lineLayer
                    .getSource()
                    .getFeatureInfoUrl(evt.coordinate, viewResolution, "EPSG:3857", {
                        INFO_FORMAT: "application/json",
                    });

                if (lineUrl) {
                    fetch(lineUrl)
                        .then(response => {
                            if (!response.ok) {
                                throw new Error(`HTTP error! Status: ${response.status}`);
                            }
                            return response.json();
                        })
                        .then(data => {
                            if (data.features && data.features.length > 0) {
                                clickedSomething = true;
                                handleLineClick(data.features[0], evt.coordinate, lineLabelOverlay, country);
                            }
                        })
                        .catch(error => console.error(`Failed to load line data from ${lineUrl}:`, error));
                }
            }
        }

        if (!clickedSomething) {
            resetCharts(country);
            document.getElementById("map-label").style.display = "none";
            document.getElementById("line-map-label").style.display = "none";
        }
    });
}

export function handleBusClick(busFeature, coordinate, labelOverlay, country) {
    const busId = busFeature.properties.Bus;
    document.getElementById("line-map-label").innerHTML = "";
    updateLabelForBus(busId, coordinate, labelOverlay);
    loadNominalGeneratorCapacityData(country, busId);
    loadOptimalGeneratorCapacityData(country, busId);
    loadNominalStorageCapacityData(country, busId);
    loadOptimalStorageCapacityData(country, busId);
}

export function handleLineClick(lineFeature, coordinate, lineLabelOverlay, country) {
    const lineId = lineFeature.properties.Line;
    document.getElementById("map-label").innerHTML = "";
    updateLabelForLine(lineId, coordinate, lineLabelOverlay);
    loadLineData(country, lineId);
}

export function updateLabelForBus(busId, coordinate, labelOverlay) {
    const labelElement = document.getElementById("map-label");
    labelElement.innerHTML = `Bus: ${busId}`;
    if (busId) {
        labelElement.style.display = "block";
    } else {
        labelElement.style.display = "none";
    }
    labelOverlay.setPosition(coordinate);
}

export function updateLabelForLine(lineId, coordinate, lineLabelOverlay) {
    const lineLabelElement = document.getElementById("line-map-label");
    lineLabelElement.innerHTML = `Line: ${lineId}`;
    if (lineId) {
        lineLabelElement.style.display = "block";
    } else {
        lineLabelElement.style.display = "none";
    }
    lineLabelOverlay.setPosition(coordinate);
}

export function resetCharts(country) {
    loadNominalGeneratorCapacityData(country);
    loadOptimalGeneratorCapacityData(country);
    loadNominalStorageCapacityData(country);
    loadOptimalStorageCapacityData(country);
    loadLineData(country);
    document.getElementById("map-label").style.display = "none";
    document.getElementById("line-map-label").style.display = "none";
}
