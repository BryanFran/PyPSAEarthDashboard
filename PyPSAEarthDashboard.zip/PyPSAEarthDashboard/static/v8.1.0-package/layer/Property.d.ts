declare namespace _default {
    let OPACITY: string;
    let VISIBLE: string;
    let EXTENT: string;
    let Z_INDEX: string;
    let MAX_RESOLUTION: string;
    let MIN_RESOLUTION: string;
    let MAX_ZOOM: string;
    let MIN_ZOOM: string;
    let SOURCE: string;
    let MAP: string;
}
export default _default;
//# sourceMappingURL=Property.d.ts.map