declare namespace _default {
    let POINTERMOVE: string;
    let POINTERDOWN: string;
    let POINTERUP: string;
    let POINTEROVER: string;
    let POINTEROUT: string;
    let POINTERENTER: string;
    let POINTERLEAVE: string;
    let POINTERCANCEL: string;
}
export default _default;
//# sourceMappingURL=EventType.d.ts.map