import { loadLayers, clearLayers } from './layers.js';
import { addMapEventHandlers } from './eventHandlers.js';

export async function searchLocation(query) {
  const response = await fetch(
    `https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&q=${query}`
  );
  const data = await response.json();
  return data;
}

export const countryZoomLevels = {
  Albania: 7,
  Andorra: 10,
  Armenia: 7,
  Austria: 7,
  Azerbaijan: 7,
  Belarus: 6,
  Belgium: 8,
  "Bosnia and Herzegovina": 7,
  Bulgaria: 7,
  Croatia: 7,
  Cyprus: 8,
  "Czech Republic": 7,
  Denmark: 7,
  Estonia: 7,
  Finland: 6,
  France: 6,
  Georgia: 7,
  Germany: 6,
  Greece: 6,
  Hungary: 7,
  Iceland: 6,
  Ireland: 6,
  Italy: 6,
  Kazakhstan: 5,
  Kosovo: 8,
  Latvia: 7,
  Liechtenstein: 9,
  Lithuania: 7,
  Luxembourg: 9,
  Malta: 9,
  Moldova: 7,
  Monaco: 10,
  Montenegro: 8,
  Netherlands: 7,
  "North Macedonia": 7,
  Norway: 5,
  Poland: 6,
  Portugal: 6,
  Romania: 6,
  Russia: 4,
  "San Marino": 10,
  Serbia: 7,
  Slovakia: 7,
  Slovenia: 7,
  Spain: 6,
  Sweden: 5,
  Switzerland: 7,
  Turkey: 6,
  Ukraine: 6,
  "United Kingdom": 6,
  "Vatican City": 11,
  Afghanistan: 6,
  Armenia: 7,
  Azerbaijan: 7,
  Bahrain: 8,
  Bangladesh: 7,
  Bhutan: 8,
  Brunei: 8,
  Cambodia: 7,
  China: 5,
  Cyprus: 8,
  Georgia: 7,
  India: 5,
  Indonesia: 5,
  Iran: 6,
  Iraq: 7,
  Israel: 7,
  Japan: 6,
  Jordan: 7,
  Kazakhstan: 5,
  Kuwait: 8,
  Kyrgyzstan: 7,
  Laos: 7,
  Lebanon: 8,
  Malaysia: 6,
  Maldives: 9,
  Mongolia: 6,
  Myanmar: 6,
  Nepal: 7,
  "North Korea": 7,
  Oman: 7,
  Pakistan: 6,
  Palestine: 9,
  Philippines: 6,
  Qatar: 8,
  Russia: 4,
  "Saudi Arabia": 6,
  Singapore: 10,
  "South Korea": 7,
  "Sri Lanka": 7,
  Syria: 7,
  Taiwan: 7,
  Tajikistan: 7,
  Thailand: 6,
  "Timor-Leste": 8,
  Turkey: 6,
  Turkmenistan: 7,
  "United Arab Emirates": 8,
  Uzbekistan: 6,
  Vietnam: 6,
  Yemen: 7,
  "Antigua and Barbuda": 9,
  Argentina: 5,
  Bahamas: 7,
  Barbados: 10,
  Belize: 8,
  Bolivia: 6,
  Brazil: 5,
  Canada: 4,
  Chile: 5,
  Colombia: 5.74,
  "Costa Rica": 8,
  Cuba: 7,
  Dominica: 10,
  "Dominican Republic": 8,
  Ecuador: 7,
  "El Salvador": 9,
  Grenada: 10,
  Guatemala: 7,
  Guyana: 7,
  Haiti: 8,
  Honduras: 7,
  Jamaica: 9,
  Mexico: 5,
  Nicaragua: 7,
  Panama: 8,
  Paraguay: 7,
  Peru: 6,
  "Saint Kitts and Nevis": 10,
  "Saint Lucia": 10,
  "Saint Vincent and the Grenadines": 10,
  Suriname: 7,
  "Trinidad and Tobago": 9,
  "United States": 4,
  Uruguay: 7,
  Venezuela: 6,
  Algeria: 5,
  Angola: 6,
  Benin: 7,
  Botswana: 6,
  "Burkina Faso": 6,
  Burundi: 8,
  "Cabo Verde": 10,
  Cameroon: 6,
  "Central African Republic": 6,
  Chad: 5,
  Comoros: 10,
  "Congo, Democratic Republic of the": 5,
  "Congo, Republic of the": 7,
  Djibouti: 8,
  Egypt: 6,
  "Equatorial Guinea": 8,
  Eritrea: 7,
  Eswatini: 9,
  Ethiopia: 6,
  Gabon: 7,
  Gambia: 8,
  Ghana: 7,
  Guinea: 7,
  "Guinea-Bissau": 8,
  "Ivory Coast": 7,
  Kenya: 6,
  Lesotho: 8,
  Liberia: 7,
  Libya: 5,
  Madagascar: 6,
  Malawi: 7,
  Mali: 5,
  Mauritania: 5,
  Mauritius: 10,
  Morocco: 6,
  Mozambique: 6,
  Namibia: 6,
  Niger: 6,
  Nigeria: 6.11,
  Rwanda: 9,
  "Sao Tome and Principe": 10,
  Senegal: 7,
  Seychelles: 10,
  "Sierra Leone": 8,
  Somalia: 6,
  "South Africa": 6,
  "South Sudan": 6,
  Sudan: 5,
  Tanzania: 6,
  Togo: 8,
  Tunisia: 7,
  Uganda: 7,
  Zambia: 6,
  Zimbabwe: 7,
  Australia: 4,
  Fiji: 7,
  Kiribati: 8,
  "Marshall Islands": 7,
  Micronesia: 8,
  Nauru: 10,
  "New Zealand": 6,
  Palau: 9,
  "Papua New Guinea": 6,
  Samoa: 8,
  "Solomon Islands": 7,
  Tonga: 8,
  Tuvalu: 10,
  Vanuatu: 7,
};

export function autocomplete(inp) {
  let currentFocus;

  inp.addEventListener("input", function (e) {
    let a,
      b,
      i,
      val = this.value;
    closeAllLists();
    if (val.length < 3) {
      return false;
    }
    currentFocus = -1;

    a = document.createElement("DIV");
    a.setAttribute("id", this.id + "autocomplete-list");
    a.setAttribute("class", "autocomplete-items");
    this.parentNode.appendChild(a);

    for (i in countryZoomLevels) {
      if (i.toUpperCase().includes(val.toUpperCase())) {
        b = document.createElement("DIV");
        b.innerHTML = "<strong>" + i.substr(0, val.length) + "</strong>";
        b.innerHTML += i.substr(val.length);
        b.innerHTML += "<input type='hidden' value='" + i + "'>";
        b.addEventListener("click", function (e) {
          inp.value = this.getElementsByTagName("input")[0].value;
          closeAllLists();
          // Trigger loading layers for the selected country
          const map = window.map; // Assuming map is globally accessible
          const overlays = window.overlays;
          clearLayers(map);
          const layers = loadLayers(map, inp.value.toLowerCase());
          addMapEventHandlers(map, layers.buses, layers.lines, overlays);
        });
        a.appendChild(b);
      }
    }
  });

  function closeAllLists(elmnt) {
    var x = document.getElementsByClassName("autocomplete-items");
    for (var j = 0; j < x.length; j++) {
      if (elmnt != x[j] && elmnt != inp) {
        x[j].parentNode.removeChild(x[j]);
      }
    }
  }

  document.addEventListener("click", function (e) {
    closeAllLists(e.target);
  });
}

export function initializeSearch(map, onCountrySelected) {
  autocomplete(document.getElementById("location-search"));

  document
    .getElementById("location-search")
    .addEventListener("keypress", async function (e) {
      if (e.key === "Enter") {
        e.preventDefault();
        const searchQuery = this.value;
        const locations = await searchLocation(searchQuery);

        if (locations.length > 0) {
          const firstLocation = locations[0];
          const coords = [
            parseFloat(firstLocation.lon),
            parseFloat(firstLocation.lat),
          ];
          const country = firstLocation.address.country;
          const zoomLevel = countryZoomLevels[country] || 10;

          map.getView().animate({
            center: ol.proj.fromLonLat(coords),
            zoom: zoomLevel,
          });

          onCountrySelected(country);
        }
      }
    });

  document
    .getElementById("location-search-form")
    .addEventListener("submit", async function (e) {
      e.preventDefault();
      const searchQuery = document.getElementById("location-search").value;
      const locations = await searchLocation(searchQuery);

      if (locations && locations.length > 0) {
        const firstLocation = locations[0];
        const coords = [
          parseFloat(firstLocation.lon),
          parseFloat(firstLocation.lat),
        ];
        const country = firstLocation.address.country;
        const zoomLevel = countryZoomLevels[country] || 10;

        map.getView().animate({
          center: ol.proj.fromLonLat(coords),
          zoom: zoomLevel,
        });

        onCountrySelected(country);
      }
    });
}
