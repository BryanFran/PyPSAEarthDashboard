// urlHandling.js

export function updateUrlWithCurrentView(map) {
  const view = map.getView();
  const center = ol.proj.toLonLat(view.getCenter());
  const zoom = view.getZoom();
  const queryParams = new URLSearchParams(window.location.search);

  // Update or set new query parameters
  queryParams.set('lat', center[1].toFixed(5)); // Latitude, fixed to 5 decimal places
  queryParams.set('lon', center[0].toFixed(5)); // Longitude, fixed to 5 decimal places
  queryParams.set('zoom', zoom.toFixed(2)); // Zoom level, fixed to 2 decimal places

  // Update the URL without reloading the page
  window.history.pushState({}, '', `${window.location.pathname}?${queryParams.toString()}`);
}

export function applyUrlParameters(map) {
  const queryParams = new URLSearchParams(window.location.search);
  const lat = parseFloat(queryParams.get('lat'));
  const lon = parseFloat(queryParams.get('lon'));
  const zoom = parseFloat(queryParams.get('zoom'));

  if (!isNaN(lat) && !isNaN(lon) && !isNaN(zoom)) {
      map.getView().setCenter(ol.proj.fromLonLat([lon, lat]));
      map.getView().setZoom(zoom);
  }
}

export function initializeUrlHandling(map) {
  map.on('moveend', () => updateUrlWithCurrentView(map));
  map.on('singleclick', () => updateUrlWithCurrentView(map));
  applyUrlParameters(map);
}