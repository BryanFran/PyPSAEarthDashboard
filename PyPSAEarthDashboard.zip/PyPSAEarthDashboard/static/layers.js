// layers.js

const wmsLayers = {
    'Nigeria': {
        'africa_shape': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:africa_shape&bbox=2.648432493209839,1.921666622161865,14.693286895751953,13.912005424499512&width=768&height=764&srs=EPSG:4326&styles=&format=application/openlayers3',
        'offshore_shapes': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:offshore_shapes&bbox=2.684863567352295,1.921666622161865,8.541397094726562,6.429849147796631&width=768&height=591&srs=EPSG:4326&styles=&format=application/openlayers3',
        'gadm_shapes': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:gadm_shapes&bbox=2.668430805206299,4.287360668182373,14.675124168395996,13.892009735107422&width=768&height=614&srs=EPSG:4326&styles=&format=application/openlayers3',
        'countries': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:country_shapes&bbox=2.668430805206299,4.287360668182373,14.673296928405762,13.892009735107422&width=768&height=614&srs=EPSG:4326&styles=&format=application/openlayers3',
        'all_clean_lines': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:all_clean_lines&bbox=3.148502826690674,4.559695243835449,13.139745712280273,13.028300285339355&width=768&height=650&srs=EPSG:4326&styles=&format=application/openlayers3',
        'substations': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:all_clean_substations&bbox=3.207669734954834,4.563215255737305,13.139745712280273,13.028435707092285&width=768&height=654&srs=EPSG:4326&styles=&format=application/openlayers3',
        'generators': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:All_clean_generators&bbox=3.614437580108643,4.815903663635254,8.273301124572754,12.845580101013184&width=445&height=768&srs=EPSG:4326&styles=&format=application/openlayers3',
        'lines': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:network_lines_view&bbox=4.034136363636363,6.485180952380953,12.06048,10.78015652173913&width=768&height=410&srs=EPSG:4326&styles=&format=application/openlayers3',
        'buses': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:Buses_geojson_data&bbox=2.591399908065796,6.485180854797363,12.060480117797852,10.780157089233398&width=768&height=348&srs=EPSG:4326&styles=&format=application/openlayers3'
    },
    'Colombia': {
        'africa_shape': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:geojson_africa_shape_CO&bbox=-84.80980682373047,-4.247829437255859,-66.81774139404297,15.177474021911621&width=711&height=768&srs=EPSG:4326&styles=&format=application/openlayers3',
        'offshore_shapes': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:geojson_offshore_shapes_CO&bbox=-84.80980682373047,1.448421239852905,-70.41767883300781,15.177474021911621&width=768&height=732&srs=EPSG:4326&styles=&format=application/openlayers3',
        'gadm_shapes': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:geojson_gadm_shapes_CO&bbox=-81.73292541503906,-4.227847576141357,-66.83773040771484,12.594307899475098&width=680&height=768&srs=EPSG:4326&styles=&format=application/openlayers3',
        'countries': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:geojson_country_shapes_CO&bbox=-79.00804901123047,-4.227847576141357,-66.83773040771484,12.458358764648438&width=560&height=768&srs=EPSG:4326&styles=&format=application/openlayers3',
        'all_clean_lines': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:geojson_all_clean_lines_CO&bbox=-78.76559448242188,0.829221546649933,-71.0892562866211,12.242009162902832&width=516&height=768&srs=EPSG:4326&styles=&format=application/openlayers3',
        'substations': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:geojson_all_clean_substations_CO&bbox=-78.76549530029297,0.829221546649933,-71.0892562866211,12.242009162902832&width=516&height=768&srs=EPSG:4326&styles=&format=application/openlayers3',
        'generators': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:geojson_all_clean_generators_CO&bbox=-180.0,-90.0,180.0,90.0&width=768&height=384&srs=EPSG:4326&styles=&format=application/openlayers3',
        'lines': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:geojson_network_lines_view_co_2&bbox=-78.76530456542969,1.424799919128418,-72.91921997070312,10.488049507141113&width=495&height=768&srs=EPSG:4326&styles=&format=application/openlayers3',
        'buses': 'http://localhost:8080/geoserver/PyPSAEarthDashboard/wms?service=WMS&version=1.1.0&request=GetMap&layers=PyPSAEarthDashboard:geojson_Buses_geojson_data_CO_2&bbox=-78.76530456542969,1.424799919128418,-72.91921997070312,10.488049507141113&width=495&height=768&srs=EPSG:4326&styles=&format=application/openlayers3'
    }
};

export function loadLayers(map, country) {
    const layers = wmsLayers[country];
    if (!layers) {
        console.error(`No layers found for country: ${country}`);
        return;
    }

    const loadedLayers = {};

    for (const [layerName, url] of Object.entries(layers)) {
        const layer = new ol.layer.Image({
            source: new ol.source.ImageWMS({
                url: url,
                params: { LAYERS: url.split('layers=')[1].split('&')[0], TILED: true },
                serverType: 'geoserver'
            })
        });
        map.addLayer(layer);
        loadedLayers[layerName] = layer;
    }

    return loadedLayers;
}

export function clearLayers(map) {
    const layers = map.getLayers().getArray().slice();
    layers.forEach(layer => {
        if (layer instanceof ol.layer.Image) {
            map.removeLayer(layer);
        }
    });
}