// init.js

export async function init() {
  // Creates a div element for the Bus or Line Label and then it is added to the DOM
  const labelElement = document.createElement("div");
  labelElement.id = "map-label";
  labelElement.style.position = "absolute";
  labelElement.style.backgroundColor = "rgba(255, 255, 255, 0.7)";
  labelElement.style.padding = "2px";
  labelElement.style.borderRadius = "5px";
  labelElement.style.fontSize = "0.7rem";
  labelElement.style.whiteSpace = "nowrap";
  labelElement.style.fontWeight = "bold";
  labelElement.style.display = "none"; // Initially hidden
  document.getElementById("js-map").appendChild(labelElement);

  const lineLabelElement = document.createElement("div");
  lineLabelElement.id = "line-map-label";
  lineLabelElement.style.position = "absolute";
  lineLabelElement.style.backgroundColor = "rgba(255, 255, 255, 0.7)";
  lineLabelElement.style.padding = "2px";
  lineLabelElement.style.borderRadius = "5px";
  lineLabelElement.style.fontSize = "0.7rem";
  lineLabelElement.style.whiteSpace = "nowrap";
  lineLabelElement.style.fontWeight = "bold";
  lineLabelElement.style.display = "none"; 
  document.getElementById("js-map").appendChild(lineLabelElement);

  // Map control definitions
  const fullScreenControl = new ol.control.FullScreen();
  const overViewMapControl = new ol.control.OverviewMap({
      collapsed: false,
      layers: [
          new ol.layer.Tile({
              source: new ol.source.OSM(), // Using OpenStreetMap as the source
              zIndex: 1,
              visible: true,
              opacity: 1,
          }),
      ],
  });
  const scaleLineControl = new ol.control.ScaleLine();
  const zoomSliderControl = new ol.control.ZoomSlider();
  const zoomToExtentControl = new ol.control.ZoomToExtent();

  // Map creation with defined layers and controls
  const map = new ol.Map({
      view: new ol.View({
          multiWorld: false,
          center: [1163126.8879498309, 6650038.165295189],
          zoom: 1,
          maxZoom: 20,
          minZoom: 1,
          rotation: 0,
      }),
      layers: [
          new ol.layer.Tile({
              source: new ol.source.OSM(),
          }),
      ],
      target: "js-map",
      keyboardEventTarget: document,
      controls: ol.control.defaults().extend([
          fullScreenControl,
          overViewMapControl,
          scaleLineControl,
          zoomSliderControl,
          zoomToExtentControl,
      ]),
  });

  return map;
}