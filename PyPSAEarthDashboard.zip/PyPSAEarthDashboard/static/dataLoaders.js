// dataLoaders.js
import { displayLoadComment, createPieChart, createDatasets, createDualDatasets, initChart } from './charts.js';

async function fetchData(url) {
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.indexOf('application/json') !== -1) {
            const data = await response.json();
            return data;
        } else {
            throw new Error('Response is not JSON');
        }
    } catch (error) {
        console.error('Error fetching data:', error);
        return null;
    }
}

export function loadNominalGeneratorCapacityData(country, selectedBusId = null) {
    fetchData(`/api/nominal-generator-capacity/${country}/`)
        .then((data) => {
            if (!data) return;
            if (selectedBusId) {
                const busData = data.filter(
                    (item) => item.Bus === selectedBusId && item.carrier !== "load"
                );
                const pieChartData = busData.map((item) => {
                    return {
                        label: item.carrier,
                        value: item.p_nom,
                    };
                });
                createPieChart(
                    "nominalGeneratorCapacityChart",
                    pieChartData,
                    `Nominal Generation Capacity for Bus: ${selectedBusId}`
                );
            } else {
                const capacityByBusAndType = {};
                let loadValue = 0;
                data.forEach((item) => {
                    if (item.carrier === "load") {
                        loadValue += item.p_nom;
                    } else {
                        if (!capacityByBusAndType[item.Bus]) {
                            capacityByBusAndType[item.Bus] = {};
                        }
                        const carrierType = item.carrier;
                        capacityByBusAndType[item.Bus][carrierType] =
                            (capacityByBusAndType[item.Bus][carrierType] || 0) + item.p_nom;
                    }
                });
                displayLoadComment("nominalGeneratorCapacityChart", loadValue);
                const chartData = createDatasets(capacityByBusAndType);
                initChart(
                    "nominalGeneratorCapacityChart",
                    chartData,
                    "bar",
                    "Nominal Generation Capacity per Bus",
                    "Capacity (MW)",
                    "Generator Type"
                );
            }
        })
        .catch((error) => console.error("Error loading data:", error));
}

export function loadOptimalGeneratorCapacityData(country, selectedBusId = null) {
    fetchData(`/api/optimal-generator-capacity/${country}/`)
        .then((data) => {
            if (!data) return;
            if (selectedBusId) {
                const busData = data.filter(
                    (item) => item.Bus === selectedBusId && item.carrier !== "load"
                );
                const pieChartData = busData.map((item) => {
                    return {
                        label: item.carrier,
                        value: item.p_nom_opt,
                    };
                });
                createPieChart(
                    "optimalGeneratorCapacityChart",
                    pieChartData,
                    `Optimal Generation Capacity for Bus: ${selectedBusId}`
                );
            } else {
                const capacityByBusAndType = {};
                let loadValue = 0;
                data.forEach((item) => {
                    if (item.carrier === "load") {
                        loadValue += item.p_nom_opt;
                    } else {
                        if (!capacityByBusAndType[item.Bus]) {
                            capacityByBusAndType[item.Bus] = {};
                        }
                        const carrierType = item.carrier;
                        capacityByBusAndType[item.Bus][carrierType] =
                            (capacityByBusAndType[item.Bus][carrierType] || 0) +
                            item.p_nom_opt;
                    }
                });
                displayLoadComment("optimalGeneratorCapacityChart", loadValue);
                const chartData = createDatasets(capacityByBusAndType);
                initChart(
                    "optimalGeneratorCapacityChart",
                    chartData,
                    "bar",
                    "Optimal Generator Capacity per Bus",
                    "Capacity (MW)",
                    "Generator Type"
                );
            }
        })
        .catch((error) => console.error("Error loading data:", error));
}

export function loadNominalStorageCapacityData(country, selectedBusId = null) {
    fetchData(`/api/nominal-storage-capacity/${country}/`)
        .then((data) => {
            if (!data) return;
            let busData;
            if (selectedBusId) {
                busData = data.filter((item) => item.Bus === selectedBusId);
            } else {
                busData = data;
            }
            if (busData.length === 0 && selectedBusId) {
                document.getElementById(
                    "nominalStorageCapacityChart"
                ).innerHTML = `No storage data available for Bus: ${selectedBusId}`;
            } else {
                const capacityByBusAndType = busData.reduce((acc, item) => {
                    acc[item.Bus] = acc[item.Bus] || {};
                    acc[item.Bus][item.carrier] =
                        (acc[item.Bus][item.carrier] || 0) + item.p_nom;
                    return acc;
                }, {});
                const chartData = createDatasets(capacityByBusAndType);
                initChart(
                    "nominalStorageCapacityChart",
                    chartData,
                    "bar",
                    selectedBusId
                        ? `Nominal Storage Capacity for Bus: ${selectedBusId}`
                        : "Nominal Storage Capacity per Bus",
                    "Capacity (MW)",
                    "Bus"
                );
            }
        })
        .catch((error) =>
            console.error("Error loading nominal storage capacity data:", error)
        );
}

export function loadOptimalStorageCapacityData(country, selectedBusId = null) {
    fetchData(`/api/optimal-storage-capacity/${country}/`)
        .then((data) => {
            if (!data) return;
            let busData;
            if (selectedBusId) {
                busData = data.filter((item) => item.Bus === selectedBusId);
            } else {
                busData = data;
            }
            if (busData.length === 0 && selectedBusId) {
                document.getElementById(
                    "optimalStorageCapacityChart"
                ).innerHTML = `No storage data available for Bus: ${selectedBusId}`;
            } else {
                const capacityByBusAndType = busData.reduce((acc, item) => {
                    acc[item.Bus] = acc[item.Bus] || {};
                    acc[item.Bus][item.carrier] =
                        (acc[item.Bus][item.carrier] || 0) + item.p_nom_opt;
                    return acc;
                }, {});
                const chartData = createDatasets(capacityByBusAndType);
                initChart(
                    "optimalStorageCapacityChart",
                    chartData,
                    "bar",
                    selectedBusId
                        ? `Optimal Storage Capacity for Bus: ${selectedBusId}`
                        : "Optimal Storage Capacity per Bus",
                    "Capacity (MW)",
                    "Bus"
                );
            }
        })
        .catch((error) =>
            console.error("Error loading optimal storage capacity data:", error)
        );
}

export function loadLineData(country, selectedLineId = null) {
    fetchData(`/api/line-data/${country}/`)
        .then((data) => {
            if (!data) return;
            if (selectedLineId) {
                const lineData = data.find((item) => item.Line === selectedLineId);
                if (lineData) {
                    const pieChartData = [
                        { label: "Nominal Capacity", value: lineData.s_nom },
                        { label: "Optimal Capacity", value: lineData.s_nom_opt },
                    ];
                    createPieChart(
                        "lineDataChart",
                        pieChartData,
                        `Nominal vs. Optimal Capacity for Line: ${selectedLineId}`
                    );
                } else {
                    document.getElementById(
                        "lineDataChart"
                    ).innerHTML = `No data available for Line: ${selectedLineId}`;
                }
            } else {
                const sNomData = {};
                const sNomOptData = {};
                data.forEach((item) => {
                    sNomData[item.Line] = item.s_nom;
                    sNomOptData[item.Line] = item.s_nom_opt;
                });
                const chartData = createDualDatasets(sNomData, sNomOptData);
                initChart(
                    "lineDataChart",
                    chartData,
                    "bar",
                    "Line Capacities Comparison",
                    "Capacity (MW)",
                    "Line"
                );
            }
        })
        .catch((error) => console.error("Error loading line data:", error));
}
