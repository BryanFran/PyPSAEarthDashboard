export function addLayerVisibilityHandlers(layers) {
    // Define layer toggles
    const layerToggles = [
        { id: "toggle-africa-shape", layer: layers.africa_shape },
        { id: "toggle-offshore-shapes", layer: layers.offshore_shapes },
        { id: "toggle-gadm-shapes", layer: layers.gadm_shapes },
        { id: "toggle-countries", layer: layers.countries },
        { id: "toggle-all-clean-lines", layer: layers.all_clean_lines },
        { id: "toggle-lines", layer: layers.lines },
        { id: "toggle-all-clean-generators", layer: layers.generators },
        { id: "toggle-all-clean-substations", layer: layers.substations },
        { id: "toggle-buses", layer: layers.buses },
    ];

    // Attach event listeners to each toggle
    layerToggles.forEach(toggle => {
        const toggleElement = document.getElementById(toggle.id);
        if (toggleElement) {
            toggleElement.addEventListener("change", function () {
                if (toggle.layer) {
                    toggle.layer.setVisible(this.checked);
                }
            });
        }
    });
}

export function updateLayerVisibility(layers) {
    // Define layer toggles
    const layerToggles = [
        { id: "toggle-africa-shape", layer: layers.africa_shape },
        { id: "toggle-offshore-shapes", layer: layers.offshore_shapes },
        { id: "toggle-gadm-shapes", layer: layers.gadm_shapes },
        { id: "toggle-countries", layer: layers.countries },
        { id: "toggle-all-clean-lines", layer: layers.all_clean_lines },
        { id: "toggle-lines", layer: layers.lines },
        { id: "toggle-all-clean-generators", layer: layers.generators },
        { id: "toggle-all-clean-substations", layer: layers.substations },
        { id: "toggle-buses", layer: layers.buses },
    ];

    // Update visibility of each toggle
    layerToggles.forEach(toggle => {
        const toggleElement = document.getElementById(toggle.id);
        if (toggleElement) {
            toggleElement.checked = toggle.layer.getVisible();
        }
    });
}
